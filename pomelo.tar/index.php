<?php include 'header.php'; ?>

<div class="product">
	<div class="picture">
		<img class="pc" src="img/pomelo-01.png">
		<img class="mobile" src="img/pomelo_m-01.png">
	</div>
	<div class="text">
		<img src="img/text-01.svg" alt="">
	</div>
</div>

<main>
	<form id="order" action="add_order.php" method="post" accept-charset="utf-8">
		<section class="purchaser">
			<div class="big_title">
				訂購人資料
			</div>
			<div class="table">
				<div class="field">
					<label for=""><i class="icon-name"></i></label>
					<input type="text" name="p_name" value="" placeholder="姓名 / Name" required>
				</div>
				<div class="field">
					<label for=""><i class="icon-phone"></i></label>
					<input type="text" name="p_phone" value="" placeholder="電話 / Phone" required>
				</div>
			</div>
		</section>

		<section class="addressee">
			<div class="big_title">
				收件人資料
			</div>
			<div class="table">
				<div class="addressee_person">
					<input type="hidden" name="addressee_person" value="1">
					<div class="person" id="person1">
						<div class="person_inf">
							<div class="field">
								<label for=""><i class="icon-name"></i></label>
								<input type="text" name="a_name[]" value="" placeholder="姓名 / Name" required>
							</div>
							<div class="field">
								<label for=""><i class="icon-phone"></i></label>
								<input type="text" name="a_phone[]" value="" placeholder="電話 / Phone" required>
							</div><!--
							--><div class="field">
								<label for=""><i class="icon-box"></i></label>
								<input type="number" name="num[]" min="1" placeholder="數量" onchange="count_total();" required>
								<span>箱</span>
							</div>
							<div class="field" class="address">
								<label for=""><i class="icon-address"></i></label>
								<div data-role="county" data-name="county[]" class="select_style county"><i class="icon-down"></i></div>
								<div data-role="district" data-name="district[]" class="select_style district"><i class="icon-down"></i></div>
								<div data-role="zipcode" data-name="zipcode[]" class="zipcode"></div>
								<input type="text" name="address[]" value="" placeholder="地址 / Road" class="road" required>
							</div>					
							<div class="field">
								<label for=""><i class="icon-msg"></i></label>
								<input type="text" name="msg[]" value="" placeholder="備註 / Notice">
							</div>					
						</div><!--  
						--><div class="person_del" onclick="removeperson(this);"><i class="icon-del"></i></div>
					</div>
				</div>

				<div class="add_btn">
					<button type="button" onclick="addperson();"><i class="icon-add"></i>新增收件人</button>
				</div>
			</div>
		</section>

		<section class="payment">
			<div class="big_title">
				付款方式
			</div>
			<div class="table">
				<div class="btn">
					<input type="radio" name="payment" value="pay" placeholder="" id="pay1" checked>
					<label for="pay1">貨到付款</label>
				</div>
				<div class="btn">
					<input type="radio" name="payment" value="atm" placeholder="" id="pay2">
					<label for="pay2">匯款</label>
				</div>
			</div>
		</section>

		<section class="form_bottom">
			<div class="total">
				總計 <span id="box_total">1</span> 箱，共 <span id="price_total">900</span> 元
			</div>
			<button type="submit">確認送出<i class="icon-send"></i></button>
		</section>
	</form>
</main>

<div class="search_icon">
	<i class="icon-search"></i>
	<form action="search.php" method="get" accept-charset="utf-8">
		<input type="text" name="order" value="" placeholder="輸入訂單編號" required>
		<button type="submit"><i class="icon-search"></i></button>
	</form>
</div>


<?php include 'footer.php'; ?>

<script type="text/javascript">
$(function(){
	$('#person1').twzipcode({
		'detect': true,
		'readonly': true
	});

	$(".search_icon > i").on("click", function(){
		$(".search_icon").toggleClass("hover");
	})

	$("#order").submit(function(){
		var submit = true;

		$(this).find("input[type=text]").each(function(){
			if ($(this).prop("required")){
				if ($(this).val() == '') {
					$(this).parents(".field").addClass("error")
					submit = false;
				}
			}
		})

		$(this).find("input[type=number]").each(function(){
			if ($(this).prop("required")){
				if ($(this).val() == '' || $(this).val() < 1) {
					$(this).parents(".field").addClass("error")
					submit = false;
				}
			}
		})

		return submit;
	})

	$("#order input[type=text]").on('change', function(){
		var parent = $(this).parents(".field");
		if (parent.hasClass("error")) {
			parent.removeClass("error");
		}
	})
	$("#order input[type=number]").on('change', function(){
		var parent = $(this).parents(".field");
		if (parent.hasClass("error")) {
			parent.removeClass("error");
		}
	})
})

// 新增收件人
function addperson(){
	var num = parseInt($("input[name=addressee_person]").val()) + 1;
	var person = $(".person").first().contents().clone();
	var person_html = $('<div class="person" id="person'+num+'"></div>');
		person_html.append(person);

	$(".addressee_person").append(person_html);
	$('#person'+num+" input[name='a_name[]']").val("");
	$('#person'+num+" input[name='a_phone[]']").val("");
	$('#person'+num+" input[name='num[]']").val(1);
	$('#person'+num+" input[name='address[]']").val("");
	$('#person'+num+" input[name='msg[]']").val("");
	$('#person'+num+" .county select").remove();
	$('#person'+num+" .district select").remove();
	$('#person'+num+" .zipcode").empty();

	$('#person'+num).twzipcode({
		'detect': true,
		'readonly': true
	});

	$("input[name=addressee_person]").val(num);
	count_total();
}

// 刪除收件人
function removeperson(e){
	var parent = $(e).parents(".person");

	$(parent).remove();
	count_total();
}

function count_total(){
	var sum = 0;
	$("input[name='num[]']").each(function() {
		sum += parseInt($(this).val());
	});

	$("#box_total").text(sum);
	$("#price_total").text(numeral(sum*900).format('0,0'));
}
</script>