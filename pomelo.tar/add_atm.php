<?php 
header("Content-Type: text/html; charset=utf-8");
if (empty($_POST['atm_num']) || empty($_POST['atm_date'])) {
	echo '<script type="text/javascript">';
	echo 'history.back();';
	echo 'alert("欄位不可為空值");';
	echo '</script>';
}else{
	include("connMysql.php");
	
	if (!$seldb) die("資料庫選擇失敗");

	$sql_query  = "UPDATE `pomelo_order` SET ";
	$sql_query .= "`atm_num` = '".$_POST['atm_num']."',";
	$sql_query .= "`atm_time` = '".$_POST['atm_date']."',";
	$sql_query .= "`payment_status` = '1' ";	
	$sql_query .= "WHERE `order_num` = '".$_GET['order']."';";
	mysql_query($sql_query);

	echo '<script type="text/javascript">';
	echo 'location.href="/search.php?order='.$_GET['order'].'";';
	echo 'alert("我們會盡快確認您的匯款");';
	echo '</script>';
}
?>