<?php phpinfo();
 ?>