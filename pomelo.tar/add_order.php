<?php 
header("Content-Type: text/html; charset=utf-8");
date_default_timezone_set("Asia/Taipei");
include("connMysql.php");

if (!$seldb) die("資料庫選擇失敗");

$sql_query = "INSERT INTO `pomelo_order`(`order_time`, `a_name`, `a_phone`, `p_name`, `p_phone`, `p_num`, `p_address`, `p_msg`, `payment_type`, `payment_status`, `order_status`, `receive_status`) VALUES";
foreach ($_POST["a_name"] as $i => $value) {
	$sql_query .= "(";
	$sql_query .= "'".date("Y-m-d H:i:s")."',";	
	$sql_query .= "'".$_POST["p_name"]."',";
	$sql_query .= "'".$_POST["p_phone"]."',";
	$sql_query .= "'".$_POST["a_name"][$i]."',";
	$sql_query .= "'".$_POST["a_phone"][$i]."',";
	$sql_query .= "'".$_POST["num"][$i]."',";
	$sql_query .= "'".$_POST["zipcode"][$i]." ".$_POST["county"][$i].$_POST["district"][$i].$_POST["address"][$i]."',";
	$sql_query .= "'".$_POST["msg"][$i]."',";
	$sql_query .= "'".$_POST["payment"]."',";

	if ($_POST["payment"] == "pay") {
		$sql_query .= "'',";
	}else{
		$sql_query .= "'0',";
	}

	$sql_query .= "'order',";
	$sql_query .= "'0'";

	if ($i+1 == count($_POST["a_name"])) {
		$sql_query .= ");";	
	}else{
		$sql_query .= "),";	
	}
}

$response = mysql_query($sql_query);
$order_id = mysql_insert_id();
$order_num = crypt($order_id, "Ou");

foreach ($_POST["a_name"] as $i => $value) {
	$sql_query  = "UPDATE `pomelo_order` SET ";
	$sql_query .= "`order_num` = '".$order_num."'";
	$sql_query .= "WHERE `order_id` = ".$order_id;
	mysql_query($sql_query);
	$order_id++;
}

header("Location: search.php?order=".$order_num."&success=true");
 
?>