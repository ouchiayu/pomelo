<?php include 'header.php'; ?>
<?php 
header("Content-Type: text/html; charset=utf-8");
include("connMysql.php");

if (!$seldb) die("資料庫選擇失敗");

$sql_query = "SELECT * FROM `pomelo_order` WHERE `order_num` = '".$_GET["order"]."';";
$order_response = mysql_query($sql_query);
$order = array();
while ($order[] = mysql_fetch_assoc($order_response));
unset($order[count($order)-1]);

// 計算總箱數
foreach ($order as $value) {
	$box_total += $value['p_num'];
}
?>

<?php if (empty($order)): ?>
	<h1>查無此訂單</h1>
	<main class="order error">
		<section class="subtitle">
			抱歉，查詢不到此訂單，請重新確認訂單編號
			<form action="search.php" method="get" accept-charset="utf-8">
				<input type="text" name="order" value="" placeholder="輸入訂單編號" required>
				<button type="submit"><i class="icon-search"></i></button>
			</form>
		</section>
	</main>
<?php else: ?>
	<h1><?php echo (isset($_GET["success"]))? "訂購成功":$_GET["order"] ?></h1>
	<main class="order">
		<section class="subtitle">
			請自行保留訂單編號<div class="order_num"><?php echo $_GET["order"] ?></div>以便後續查詢
		</section>
		<section class="purchaser">
			<div class="big_title">
				訂購人資料
			</div>
			<div class="table">
				<div class="field">
					<label for=""><i class="icon-name"></i></label>
					<input type="text" name="p_name" value="<?php echo $order[0]['a_name']; ?>" readonly>
				</div>
				<div class="field">
					<label for=""><i class="icon-phone"></i></label>
					<input type="text" name="p_phone" value="<?php echo $order[0]['a_phone']; ?>" readonly>
				</div>
			</div>
		</section>

		<section class="addressee">
			<div class="big_title">
				收件人資料
			</div>
			<div class="table">
				<div class="addressee_person">
					<input type="hidden" name="addressee_person" value="1">
					<?php foreach ($order as $person): ?>
						<div class="person" id="person1">
							<div class="person_inf">
								<div class="field">
									<label for=""><i class="icon-name"></i></label>
									<input type="text" name="a_name[]" value="<?php echo $person['p_name']; ?>" readonly>
								</div>
								<div class="field">
									<label for=""><i class="icon-phone"></i></label>
									<input type="text" name="a_phone[]" value="<?php echo $person['p_phone']; ?>" readonly>
								</div><!--
								--><div class="field">
									<label for=""><i class="icon-box"></i></label>
									<input type="number" name="num[]" value="<?php echo $person['p_num']; ?>" min="1" readonly>
									<span>箱</span>
								</div>
								<div class="field" class="address">
									<label for=""><i class="icon-address"></i></label>
									<input type="text" name="address[]" value="<?php echo $person['p_address']; ?>" class="road" readonly>
								</div>
								<?php if ($person['p_msg']): ?>
									<div class="field">
										<label for=""><i class="icon-msg"></i></label>
										<input type="text" name="msg[]" value="<?php echo $person['p_msg']; ?>" readonly>
									</div>					
								<?php endif ?>					
							</div>

							<div class="order_status">
								<div class="all_status">
									<div class="status<?php
										if ($person['order_status'] == 'order') {
											echo " now";
										}else{
											echo " pass";
										}
									?>">
										訂購成功
									</div><div class="line">
									</div><div class="status<?php
										if ($person['order_status'] == 'pack') {
											echo " now";
										}elseif($person['order_status'] != 'order'){
											echo " pass";
										}
									?>">
										阿婆裝箱中
									</div><div class="line">
									</div><div class="status<?php
										if ($person['order_status'] == 'ship') {
											echo " now";
										}elseif($person['order_status'] == 'arrive' ){
											echo " pass";
										}
									?>">
										紅柚運送中
									</div><div class="line">
									</div><div class="status<?php
										if ($person['order_status'] == 'arrive') echo " now"; if($person['order_status'] == 'ship') echo ' check'; ?>" <?php if($person['order_status'] == 'ship') echo 'onclick="changstatus('."'".$person['order_id']."'".');"' ?>>
										貨物已到達
									</div>
								</div>
							</div>
						</div>
					<?php endforeach ?>
				</div>
			</div>
		</section>

		<section class="payment">
			<div class="big_title">
				付款方式
			</div>
			<div class="table">
				<?php if ($order[0]['payment_type'] == "pay"): ?>
					<div class="btn">
						<label for="pay1">貨到付款</label>
					</div>
				<?php else: ?>
					<div class="btn atm">
						<label for="pay2">
							<div>匯款資訊</div>
							<?php if ($order[0]['payment_status'] == '0'): ?>
								<label class="atm_inf">
									<span>匯款帳戶: </span>
									<p>
										日盛銀行-八德分行 (815-0141) <br>
										戶名: 簡麗華 <span>帳號: 014-10034963-000</span>
									</p>
								</label>
							<?php endif ?>

							<form id="atm_form" action="add_atm.php?order=<?php echo $_GET["order"] ?>" method="post" accept-charset="utf-8">
								<div class="field">
									<label for=""><i class="icon-bank"></i></label>
									<input type="text" name="atm_num" placeholder="匯款帳號" <?php if($order[0]['payment_status'] != "0") echo "readonly"; ?> value="<?php if($order[0]['payment_status'] != "0") echo $order[0]['atm_num']; ?>" required>
								</div>
								<div class="field">
									<label for=""><i class="icon-date"></i></label>
									<input type="text" id="datepicker" name="atm_date" placeholder="匯款日期" <?php if($order[0]['payment_status'] != "0") echo "readonly"; ?> value="<?php if($order[0]['payment_status'] != "0") echo $order[0]['atm_time']; ?>" required>
								</div>
								<?php if ($order[0]['payment_status'] == "0"): ?>
									<button type="submit">我已匯款</button>
								<?php elseif($order[0]['payment_status'] == "1"): ?>
									<div class="button">匯款確認中</div>
								<?php else: ?>
									<div class="button">付款完成</div>
								<?php endif ?>
								
							</form>
						</label>
					</div>
				<?php endif ?>
			</div>
		</section>

		<section class="form_bottom">
			<div class="total">
				總計 <span id="box_total"><?php echo $box_total; ?></span> 箱，共 <span id="price_total"><?php echo number_format($box_total*900); ?></span> 元
			</div>
		</section>
	</main>
<?php endif ?>

<div class="home_icon">
	<a href="/"><i class="icon-home"></i>回首頁</a>
</div>



<?php include 'footer.php'; ?>

<script type="text/javascript">
$(function(){
	<?php if ($order[0]['payment_status'] == '0'): ?>
		$("#datepicker").datepicker();
		$("#datepicker").datepicker("option", "dateFormat", "yy-mm-dd");
	<?php endif ?>
});

// 變更訂單狀態
	function changstatus(id){
		var check = confirm("確定已經收到貨款了嗎?");

		if (check) {
			$.ajax({
				url: "/chage_orderstatus.php",
				type: "POST",
				data: {
					'id': id,
					'status': 'arrive'
				},
				success: function(msg){
					if (msg) {
						location.reload();
					}
				}
			})
		}
	}

</script>