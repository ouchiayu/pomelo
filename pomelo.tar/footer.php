<script src="js/jquery-ui.min.js"></script>
<script src="js/jquery.twzipcode.min.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/numeral.min.js"></script>

</body>
</html>